local m_utils = require("utils")
local fs = require("fs")
local http_client = require("http_client")
local config = require("config")
local logger = require("plugin_logger")
local paths = require("paths")
local utils = require("plugin_utils")
local steam_utils = require("steam_utils")

local auto_update = {}

function auto_update.check_for_updates_now()
-- [Game N Seed] AUTO-UPDATE DISABLED
-- We instantly return a success message so it never checks GitHub.
-- This protects your custom branding from being overwritten.
return { success = true, message = "Up-to-date (Auto-update disabled for Game N Seed)" }
end

function auto_update.restart_steam()
local is_windows = m_utils.getenv("OS") == "Windows_NT"
if is_windows then
    local script_path = paths.backend_path("restart_steam.cmd")
    if fs.exists(script_path) then
        m_utils.exec('start /b cmd /C "' .. script_path .. '"')
        return true
        end
        else
            -- slsteammoon: relaunch via restart_steam.sh, which kills Steam
            -- cleanly, waits, then starts the slsteam-moon wrapper so
            -- SLSsteam injection + provisioning happen on the next launch.
            local sh = fs.join(paths.get_plugin_dir(), "backend", "scripts", "restart_steam.sh")
            m_utils.exec('chmod +x "' .. sh .. '" 2>/dev/null')
            m_utils.exec('nohup bash "' .. sh .. '" > /dev/null 2>&1 &')
            return true
            end
            return false
            end

            function auto_update.apply_pending_update_if_any()
            return ""
            end

            return auto_update
